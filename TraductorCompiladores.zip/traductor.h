#include "sintactico.c"





/**Prototipos de funciones**/



void sintaxis_trad();

void elemento_trad();

void vector_trad();

void vectorA_trad();

void lista_elemento_trad();

void lista_elementoA_trad();

void objeto_trad();

void objetoA_trad();

void atributo_trad();

void lista_atributo_trad();

void lista_atributoA_trad();

void nombre_atributo_trad();

void valor_atributo_trad();

int espacios=0;



/**Funcion auxiliar**/



void string_sin_comillas(char* );

void imprimir_espacios();